//
//  QuotesTests.m
//  QuotesTests
//
//  Created by Trina Gregory on 2/22/16.
//  Copyright © 2016 Trina Gregory. All rights reserved.
//

#import <XCTest/XCTest.h>
#import "QuotesModel.h"

@interface QuotesTests : XCTestCase

@property (strong, nonatomic) QuotesModel *model;

@end

@implementation QuotesTests

- (void)setUp {
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
    
    self.model = [[QuotesModel alloc] init];
}

- (void)tearDown {
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void) logArray {
    NSDictionary *quote;
    
    for (NSUInteger i=0; i < [self.model numberOfQuotes]; i++) {
        quote = [self.model quoteAtIndex: i];
        
//        NSLog (@"Quote: %@ Author: %@", [quote objectForKey: kQuoteKey],
//               [quote objectForKey: kAuthorKey]);
        
        NSLog(@"Quote: %@ Author: %@", quote[kQuoteKey],
              quote[kAuthorKey] );
    }
    NSLog(@" ");
}

- (void)testModel {
    // This is an example of a functional test case.
    // Use XCTAssert and related functions to verify your tests produce the correct results.
    
    // local variables
    NSUInteger num;
    
    // test init
    num = 8; // I know that the init creates 8 quotes
    XCTAssertEqual(num, [self.model numberOfQuotes]);
}


- (void) testInsert {
    // local variables
    NSUInteger num;
    NSUInteger index;
    NSDictionary *quote, *addedQuote;    
    
    num = [self.model numberOfQuotes];
    index = 0;

    // Insert quote
    quote = [NSDictionary dictionaryWithObjectsAndKeys:
             @"Variables: declare once, use many", kQuoteKey,
             @"Trina Gregory", kAuthorKey, nil];
    [self.model insertQuote: quote atIndex: index];
    num = num + 1;
    XCTAssertEqual(num, [self.model numberOfQuotes]);
    addedQuote = [self.model quoteAtIndex:index];
    XCTAssertEqualObjects(quote, addedQuote);
}

- (void) testRemove {
    // local variables
    NSUInteger num;
    NSUInteger index;
    
    num = [self.model numberOfQuotes];
    index = 0;

    // Remove quote
    [self.model removeQuoteAtIndex: index];
    num = num - 1;
    XCTAssertEqual(num, [self.model numberOfQuotes]);
}

@end
