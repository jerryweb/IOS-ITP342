//
//  StudentModel.m
//  Quotes
//
//  Created by Trina Gregory on 2/22/16.
//  Copyright © 2016 Trina Gregory. All rights reserved.
//

#import "StudentModel.h"

@interface StudentModel ()

// private properties
@property (strong, nonatomic) NSMutableArray *students;

@end

@implementation StudentModel

- (instancetype) init
{
    self = [super init];
    if (self) {
        
        NSDictionary *student1 = [[NSDictionary alloc] initWithObjectsAndKeys: @"Stephen Do", kNameKey,
        @"1234567890", kIdKey, nil];
        
        NSDictionary *student2 = [NSDictionary dictionaryWithObjectsAndKeys:@"Arman Ali", kNameKey,
                                  @"0987654321", kIdKey, nil];
    
        
        _students = [[NSMutableArray alloc] initWithObjects:
                     student1, student2, nil];
        
        NSDictionary *student = [NSDictionary
            dictionaryWithObjectsAndKeys:
                @"Shandira", kNameKey, @"4536272985", kIdKey, nil];
        
        [_students addObject: student];
        
        student = [NSDictionary
                   dictionaryWithObjectsAndKeys:
                   @"Jesus", kNameKey, @"1287643258", kIdKey, nil];
        
        [_students addObject: student];
        
    }
    
    return self;
}

@end
