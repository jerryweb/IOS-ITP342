//
//  StudentModel.h
//  Quotes
//
//  Created by Trina Gregory on 2/22/16.
//  Copyright © 2016 Trina Gregory. All rights reserved.
//

#import <Foundation/Foundation.h>

static NSString * const kNameKey = @"name";
static NSString * const kIdKey = @"USCid";

@interface StudentModel : NSObject

@end
