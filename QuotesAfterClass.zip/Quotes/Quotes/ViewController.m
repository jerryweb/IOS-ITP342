//
//  ViewController.m
//  Quotes
//
//  Created by Trina Gregory on 2/22/16.
//  Copyright © 2016 Trina Gregory. All rights reserved.
//

#import "ViewController.h"
#import "QuotesModel.h"

@interface ViewController ()
// private properties
@property (strong, nonatomic) QuotesModel *model;

// IBOutlets
@property (weak, nonatomic) IBOutlet UILabel *quoteLabel;
@property (weak, nonatomic) IBOutlet UILabel *authorLabel;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    self.model = [[QuotesModel alloc] init];
    NSDictionary *quote = [self.model randomQuote];
    self.quoteLabel.text = quote[kQuoteKey];
    self.authorLabel.text = quote[kAuthorKey];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
