//
//  ViewController.h
//  Quotes
//
//  Created by Trina Gregory on 2/22/16.
//  Copyright © 2016 Trina Gregory. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

