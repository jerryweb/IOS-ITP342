//
//  DetailViewController.h
//  Lab 6
//
//  Created by LJ on 4/29/16.
//  Copyright © 2016 Jerry Webb. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DetailViewController : UIViewController

@property (strong, nonatomic) NSDictionary *place;
@end
