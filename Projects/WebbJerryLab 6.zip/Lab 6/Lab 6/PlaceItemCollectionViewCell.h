//
//  PlaceItemCollectionViewCell.h
//  Lab 6
//
//  Created by LJ on 4/25/16.
//  Copyright © 2016 Jerry Webb. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PlaceItemCollectionViewCell : UICollectionViewCell

//@property (weak, nonatomic) IBOutlet UIImageView *imageView;
//@property (weak, nonatomic) IBOutlet UILabel *placeLabel;

- (void) setPlace: (NSDictionary *) place;

@end
