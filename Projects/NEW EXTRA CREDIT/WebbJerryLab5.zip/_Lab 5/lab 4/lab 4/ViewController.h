//
//  ViewController.h
//  lab 4
//
//  Created by LJ on 3/14/16.
//  Copyright © 2016 Jerry Webb. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

